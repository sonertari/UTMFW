/* IMSpector - Instant Messenger Transparent Proxy Service
 * http://www.imspector.org/
 * (c) Lawrence Manning <lawrence@aslak.net>, 2006
 * 
 * Contributions from:
 *     Ryan Wagoner <ryan@wgnrs.dynu.com>, 2006
 *          
 * Released under the GPL v2. */

void stripnewline(char *buffer);
std::string stringprintf(const char *fmt, ...);
char *chopline(char* buffer, std::string &command, std::vector<std::string> &args, int &argc);
void debugprint(bool debugflag, const char *string, ...);
int decodebase64(std::string line, uint8_t *buffer, int bufferlen);
uint8_t decodebase64char(char c);
void tracepacket(const char *protocol, int packetcount, char *buffer, int bufferlength);
unsigned long hash(const char *str);
char *parsexmltag(bool debugmode, char* buffer, std::string &payload, int &payloadlength, 
	std::string &tag, bool &closing, std::map<std::string, std::string> &params);
void stripslash(std::string &in);
void removenewlines(std::string &in);
