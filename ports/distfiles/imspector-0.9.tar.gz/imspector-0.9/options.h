/* IMSpector - Instant Messenger Transparent Proxy Service
 * http://www.imspector.org/
 * (c) Lawrence Manning <lawrence@aslak.net>, 2006
 *          
 * Released under the GPL v2. */

class Options
{
	public:
		bool readoptionsfile(std::string filename);
		std::string operator[](const char *key);
		std::vector<std::string> getkeys(void);
	
	private:
		std::map<std::string, std::string> params;
};
